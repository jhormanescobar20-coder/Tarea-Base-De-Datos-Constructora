package com.universidad.estudiantes_api.calculadora;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;
import org.junit.platform.suite.api.SuiteDisplayName;

@Suite
@SuiteDisplayName("Suite de Pruebas de Calculadora")
@SelectClasses({
        ValorAbsolutoTest.class,
        NumeroPrimoTest.class,
        OperacionesTest.class,
        DivisionTest.class
})
public class AllTestsSuite {
    // Esta clase permanece vacía.
    // Solo se utiliza como contenedor para las anotaciones de arriba.
}