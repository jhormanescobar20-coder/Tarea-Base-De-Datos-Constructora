package com.universidad.estudiantes_api.calculadora;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Tests: valorAbsoluto()")
class ValorAbsolutoTest {

    private Calculadora calc;

    @BeforeEach
    void setUp() {
        calc = new Calculadora();
    }

    @Test
    @DisplayName("número positivo: |5| = 5")
    void testPositivo() {
        assertEquals(5, calc.valorAbsoluto(5));
    }

    @Test
    @DisplayName("número negativo: |-8| = 8")
    void testNegativo() {
        // Caso más importante: convierte negativo en positivo
        assertEquals(8, calc.valorAbsoluto(-8));
    }

    @Test
    @DisplayName("cero: |0| = 0")
    void testCero() {
        // Edge case: el cero no cambia
        assertEquals(0, calc.valorAbsoluto(0));
    }

    @Test
    @DisplayName("valor mínimo int (edge case extremo)")
    void testMuyNegativo() {
        assertEquals(100, calc.valorAbsoluto(-100));
    }
}