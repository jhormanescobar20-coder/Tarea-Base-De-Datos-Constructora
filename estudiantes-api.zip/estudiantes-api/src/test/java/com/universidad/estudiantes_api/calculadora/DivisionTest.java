package com.universidad.estudiantes_api.calculadora;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Tests: dividir()")
class DivisionTest {

    private Calculadora calc;

    @BeforeEach
    void setUp() { calc = new Calculadora(); }

    @Test
    @DisplayName("10 dividido 2 = 5.0")
    void testDivisionExacta() {
        assertEquals(5.0, calc.dividir(10, 2), 0.001);
        //                                      ↑ delta: tolerancia para double
    }

    @Test
    @DisplayName("10 dividido 3 = 3.333...")
    void testDivisionConDecimal() {
        assertEquals(3.333, calc.dividir(10, 3), 0.001);
    }

    @Test
    @DisplayName("Dividir por cero DEBE lanzar ArithmeticException")
    void testDivisionPorCero() {
        try {
            // Intentamos ejecutar la división pasándole doubles
            calc.dividir(10.0, 0.0);

            // Si llega a esta línea, significa que NO lanzó la excepción (El test debe fallar)
            fail("Debe lanzar ArithmeticException al dividir por cero");
        } catch (ArithmeticException ex) {
            // Si cae aquí, la excepción se lanzó correctamente. Validamos el mensaje:
            assertTrue(ex.getMessage().toLowerCase().contains("cero"),
                    "El mensaje de error debe mencionar 'cero'");
        }
    }

    @Test
    @DisplayName("Dividir número negativo")
    void testDivisionNegativo() {
        assertEquals(-2.5, calc.dividir(-5, 2), 0.001);
    }
}