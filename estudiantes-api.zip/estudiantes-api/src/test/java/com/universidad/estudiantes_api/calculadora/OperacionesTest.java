package com.universidad.estudiantes_api.calculadora;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Tests: operaciones básicas")
class OperacionesTest {

    private Calculadora calc;

    @BeforeEach
    void setUp() { calc = new Calculadora(); }

    // — SUMA —
    @Test void testSumaPositivos() { assertEquals(5, calc.sumar(2, 3));   }
    @Test void testSumaNegativos() { assertEquals(-5, calc.sumar(-3, -2)); }
    @Test void testSumaCero()      { assertEquals(7, calc.sumar(7, 0));   }

    // — RESTA —
    @Test void testRestaBasica()           { assertEquals(1, calc.restar(3, 2));   }
    @Test void testRestaResultadoNegativo(){ assertEquals(-3, calc.restar(2, 5));  }
    @Test void testRestaCero()             { assertEquals(8, calc.restar(8, 0));   }

    // — MULTIPLICACIÓN —
    @Test void testMultiplicar()    { assertEquals(12, calc.multiplicar(3, 4));   }
    @Test void testMultPorCero()    { assertEquals(0, calc.multiplicar(9, 0));    }
    @Test void testMultNegativos()  { assertEquals(6, calc.multiplicar(-2, -3));  }
}