package com.universidad.estudiantes_api.calculadora;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Tests: esNumeroPrimo()")
class NumeroPrimoTest {

    private Calculadora calc;

    @BeforeEach
    void setUp() {
        calc = new Calculadora();
    }

    // — CASOS POSITIVOS: números que SÍ son primos —
    @Test
    void testDos() {
        assertTrue(calc.esNumeroPrimo(2));
    }

    @Test
    void testTres() {
        assertTrue(calc.esNumeroPrimo(3));
    }

    @Test
    void testCinco() {
        assertTrue(calc.esNumeroPrimo(5));
    }

    @Test
    void testSiete() {
        assertTrue(calc.esNumeroPrimo(7));
    }

    @Test
    void testTrece() {
        assertTrue(calc.esNumeroPrimo(13));
    }

    @Test
    void testCientoUno() {
        assertTrue(calc.esNumeroPrimo(101));
    }

    // — CASOS NEGATIVOS: números que NO son primos —
    @Test
    void testUno() {
        assertFalse(calc.esNumeroPrimo(1));
    }

    @Test
    void testCero() {
        assertFalse(calc.esNumeroPrimo(0));
    }

    @Test
    void testNegativo() {
        assertFalse(calc.esNumeroPrimo(-5));
    }

    @Test
    void testCuatro() {
        assertFalse(calc.esNumeroPrimo(4));
    }

    @Test
    void testNueve() {
        assertFalse(calc.esNumeroPrimo(9));
    }

    @Test
    void testVeintiUno() {
        assertFalse(calc.esNumeroPrimo(21));
    }
}